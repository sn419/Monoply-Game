from property_information import PropertyInfo
class Bank:
    def __init__(self, balance):
        self.balance = balance
        self.total_properties = PropertyInfo()
        self.property_in_mortgage = []

    def get_balance(self):
        '''

        :return: returns the balance
        '''
        return self.balance

    def withdraw(self, amount):
        '''

        :param amount: the amount being withdrawn
        :return: returns the balance after the amount is removed
        '''
        self.balance -= amount

    def deposit(self, amount):
        '''

        :param amount:
        :return: updates the balance by summing it with the amount
        '''
        self.balance += amount

    def sell_property(self,name):
       if self.total_properties.check(name):
           self.total_properties.remove(name)

    def remove_mortgage(self, property_name):
        for i in range(len(self.property_in_mortgage)):
            if self.property_in_mortgage[i] == property_name:
                self.property_in_mortgage.pop(i)
                self.total_properties.add(property_name)

    def add_mortgage(self, property_name):
        self.property_in_mortgage.append(property_name)

    def get_mortgage_list(self):
        '''

        :return: returns list of properties that  can be morgaged
        '''
        return self.property_in_mortgage

    def buy_property(self, property_object):
        "Check if the property is in mortgage"

        if self.check_mortgage(property_object):
            total_cost = property_object.get_cost() / 2
            self.remove_mortgage(property_object)
            self.total_properties.add(property_object)
            return total_cost

        else:
            self.total_properties.add(property_object)
            self.withdraw(property_object.get_cost())
            return property_object.get_cost()

    def mortgage(self, property_name):
        '''

        :param property_name: name of property getting motgaged
        :return: returns the money recieved from the mortgage
        '''
        money = property_name.get_cost() / 2
        self.withdraw(money)
        return money

    def check_mortgage(self, property):
        if property in self.property_in_mortgage:
            return True
        return False

    def get_own_bank_properties(self):
        '''

        :return: returns the properties
        '''
        return  self.total_properties

    # Class test needs to be done on this Class
