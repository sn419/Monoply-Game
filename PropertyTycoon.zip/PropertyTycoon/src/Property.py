class EachProperty:
    def __init__(self, name, group, current_rent, Cost, house_rent):
        self.name = name
        self.group = group
        self.cost = Cost
        self.current_rent = current_rent
        self.development = house_rent
        self.house = 0

    def get_group(self):
        '''

        :return: returns the group of the property
        '''
        return self.group

    def get_name(self):
        '''

        :return: gets the name of the property
        '''
        return self.name

    def get_cost(self):
        '''

        :return: returns the cost of the property
        '''
        return self.cost

    def get_rent(self):
        '''

        :return: returns the rent
        '''
        return self.current_rent

    def set_rent(self):
        '''

        :return: sets the rent according to which property you own
        '''
        self.house += 1
        self.current_rent = self.development[self.house]


    def can_develop_more(self):
        if self.house + 1 <= 5:
            return True
        else:
            return False
