import PlayingPlayers
import random


class Dice:
    def __init__(self):
        pass

    def random_number(self):
        '''

        :return: returns a number between 1 and 6
        '''
        x = random.randint(1, 6)
        return x

    def get_dice_number(self):
        '''

        :return: returns the sum of two random numbers, using the function above
        '''
        first = self.random_number()
        second = self.random_number()
        return first + second

    "Class needs to be tested for errors "
