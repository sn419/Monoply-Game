class personal_station:
    def __init__(self):
            self.stations = ["Brighton Station","Hove Station", "Falmer Station","Portslade Station"]
            self.rents = [25,50,100,200]
            self.index = -1
            self.current_rent = 0

    def check_station(self, name):
        if name in self.stations:
            return True
        return False

    def decrement_rent(self):
        '''

        :return: removes number of stations, and removes the rent of the station
        '''
        self.index -= 1
        self.current_rent = self.rents[self.index]

    def increment_rent(self):
        self.index += 1
        self.current_rent = self.rents[self.index]

    def get_rent(self):
        return self.current_rent


