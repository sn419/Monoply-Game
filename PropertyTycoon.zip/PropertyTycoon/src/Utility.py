import collections

class Utility:
    def __init__(self):
        self.cost = 0
        self.utilities =0

    def total_rent(self, dice_one, dice_two):
        '''

        :param dice_one: number of dice one
        :param dice_two: number of dice two
        :return: depending on which utility it lands on, will either return sum of dice multiplied by 4 or 10
        '''
        if self.utilities == 1:
            return (dice_one + dice_two) * 4
        elif self.utilities == 2:
            return (dice_one + dice_two) * 10
        else:
            return 0

    def add_utility(self ):
        '''

        :return: adding a utility
        '''
        self.utilities += 1

    def remove_utility(self):
        '''

        :return: removing a utility
        '''
        if self.utilities >0:
            self.utilities -= 1

    def get_utility(self):
        '''

        :return: returns the utility
        '''
        return self.utilities





