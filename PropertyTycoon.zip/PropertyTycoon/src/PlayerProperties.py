import collections

class PlayerProperties:
    def __init__(self):
        self.balance = 0
        self.properties = set()
        self.mortgage_properties = set()
        self.group = collections.defaultdict(int)

    def add_to_balance(self, amount):
        self.balance += amount

    def remove_from_balance(self, amount):
        self.balance -= amount

    def add_property(self, name):
        '''

        :param name:
        :return: adds the property to the name who owns it
        '''
        self.properties.add(name)

    def remove_property(self, name):
        '''

        :param name:
        :return: removes the property from the player
        '''
        if name in self.properties:
            self.properties.remove(name)

    def check_property(self):
        '''

        :return: returns true if the length of the properties is more than 0, false if less
        '''
        if len(self.properties) > 0:
            return True
        return False

    def get_cost_of_properties(self):
        return self.balance


    def select_property(self):
        '''

        :return:  "This function is used to select a property or an asset based on how much money you need"
        '''
        target_property = 0

        for each_property in self.properties:
            target_property = each_property
            break

        return target_property

    def add_to_mortgage(self, property):
        self.mortgage_properties.add(property)

    def check_in_mortgage(self, property):
        self.mortgage_properties.remove(property)

    def get_mortgage(self):
        individual_property = 0
        for element in self.mortgage_properties:
            individual_property = element
            break

        return individual_property

    def remove_mortgage(self, property):
        '''

        :param property: properties which the owner owns
        :return: removes the mortgage
        '''
        self.mortgage_properties.remove(property)

    def get_length_properties(self):
        '''

        :return: returns number of properties
        '''
        return len(self.properties)

