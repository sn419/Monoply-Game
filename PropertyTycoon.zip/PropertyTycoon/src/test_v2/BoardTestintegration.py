from Board import LinkedList, board
from PlayersPersonalInformation import PlayerInformation
#layer_name, token, current_position, Go, current_position_nod
class BoardTest():
    def __init__(self):
        self.board = LinkedList()
        self.properties = {"Turing Heights"}
        self.boardclass = board()
        self.player = PlayerInformation("jhon","",(0,0),False,self.board.head)
    "check weather every cell is assigned a cell name"

    def addtoboardTest(self):
        self.boardclass.place_index()
        placingitems = self.boardclass.get_board()
        curr = self.boardclass.get_head()
        current = curr
        while current:
            assert  not current.val == None,"the cell is empty"
            print("the cell is added")
            current = current.next
            current = current.next
            if current == curr:
                break

    "check weather a property is bought by a player"
    def add_property_test(self):
        node = self.boardclass.head
        self.boardclass.set_belong(self.player,"jhon")

        assert not node.belong != None,"the property is assigned"
        print("the property is bought")




