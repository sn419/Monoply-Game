from PlayersPersonalInformation import PlayerInformation
from Turn import Dice

import random


class agent(PlayerInformation):
    def __init__(self, player_name, token, current_position, Go, current_position_node, is_ai):
        super().__init__(player_name, token, current_position, Go, current_position_node)
        self.is_ai = is_ai

    def get_ai(self):
        return self.is_ai

    def dice(self):
        '''

        :return: returns two random numbers, both between 1 and 6, then adds the two numbers
        '''
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        summation = dice2 + dice1
