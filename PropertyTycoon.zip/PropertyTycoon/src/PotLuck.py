import queue
import pygame



class potluck():
    def __init__(self):
        self.card = [[0, "You inherit £200"],
                     [1, "You have won 2nd prize in a beauty contest, collect £50"],
                     [2, "You are up the creek with no paddle - go back to the Old Creek"],
                     [3, "Student loan refund. Collect £20"],
                     [4, "Bank error in your favour. Collect £200"],
                     [5, "Pay bill for text books of £100"],
                     [6, "Mega late night taxi bill pay £50"],
                     [7, "Advance to go"],
                     [8, "From sale of Bitcoin you get £50"],
                     [9, "Bitcoin assets fall - pay off Bitcoin short fall"],
                     [10, "Pay a £10 fine or take opportunity knocks"],
                     [11, "Pay insurance fee of £50"],
                     [12, "Savings bond matures, collect £100"],
                     [13, "Go to jail. Do not pass GO, do not collect £200"],
                     [14, "Received interest on shares of £25"],
                     [15, "It's your birthday. Collect £10 from each player"],
                     [16, "Get out of jail free"]]



        self.money = {0: 200, 1: 50, 2: "The Old Creek", 3: 20, 4: 200, 5: 100, 6: 50, 7: "Go", 8: 50, 9: 50, 10: 10,
                      11: 50, 12: 100,
                      13: "Go to Jail", 14: 25, 15: 10, 16: "jail free"}

        self.activation = {2, 17, 33}


    def check(self):
        return self.card[0]

    def dequeue(self):
        item = self.card[0]
        self.card.pop(0)
        self.card.append(item)
        return item

    def card_operation(self, bank, player,card_index):
        Bank_pays = {0, 1, 3, 4, 8, 12, 14}
        player_pays = {5, 6, 9, 10, 11}
        position = {2, 7, 13}

        if card_index[0] in Bank_pays:
            amount = self.money[card_index[0]]
            bank.withdraw(amount)
            player.deposit(amount)
            print("the operation is successful- player{}, bank {}".format(player.get_balance(), bank.get_balance()))

        elif card_index[0] in player_pays:
            amount = self.money[card_index[0]]
            bank.deposit(amount)
            player.withdraw(amount)
            print("the operation is successful- player{}, bank {}".format(player.get_balance(), bank.get_balance()))

        elif card_index[0] in position:
            jump_position = self.money[card_index[0]]
            print("it is successful")

            return jump_position

        elif card_index == 16:
            player.add_card()
            print(" The operation is successful ")

    def check_board_activation(self, index):
        if index in self.activation:
            return True
        return False
