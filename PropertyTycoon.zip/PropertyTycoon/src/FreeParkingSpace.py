class FreeParking:
    def __init__(self,position):
        self.balance = 0
        self.position = position

    def add_to_balance(self, amount):
        '''

        :param amount: the amount to add to the total balance of free parking
        :return: returns the sum of the current balance and the new amount
        '''
        self.balance += amount

    def get_balance(self):
        '''

        :return: returns the total of free parking
        '''
        total = self.balance
        self.balance = 0
        return total

    def get_position(self):
        return self.position


