import pygame, sys
from pygame.locals import *
import math
import time

pygame.init()
pygame.font.init()

"Import necessary classes"
from Turn import Dice
from Bank import Bank
from PlayingPlayers import CurrentPlaying
from PlayersPersonalInformation import PlayerInformation
from Jail import JailCell
from Board import board
from OpportunityKnocks import Opportunity
from PotLuck import potluck
from FreeParkingSpace import FreeParking
from Auction import Auctions
from Potluck_token import potlucktoken
from opportunity_token import opportunityknock

"Setting Pygame Screen"
mainClock = pygame.time.Clock()
pygame.init()
pygame.display.set_caption('Property Tycoon')
WIDTH = 1000
HEIGHT = 790
screen = pygame.display.set_mode((WIDTH, HEIGHT))

"Fonts"
Fonts = "HALO____.TTF"
font_1 = "Future TimeSplitters.otf"
STANDARD_SIZE = 20
Size = 50
FONT_TYPE = pygame.font.Font(Fonts, Size)
font1_render = pygame.font.Font(font_1, 30)
"Colors"
WHITE = (225, 225, 225)
BlACK = (0, 0, 0)
RED = (225, 17, 0)
BOARD_COLOR = (191, 219, 174)
SKY_BLUE = (154, 220, 255)
BROWN = (204, 102, 0)
BLUE = (0, 0, 255)
PURPLE = (255, 0, 255)
ORANGE = (225, 178, 102)
DEEPBLUE = (0, 0, 153)
YELLOW = (225, 225, 51)
GREEN = (0, 153, 0)
"Background image"
BACKGROUND_IMAGE = pygame.image.load("images/Main_backround.jpg")
BACKGROUND_IMAGE = pygame.transform.scale(BACKGROUND_IMAGE, (WIDTH, HEIGHT))


"Number of players playing key as instance of class and value as its token image"
player_playing_game = {}
choosen_coordinaties = []

"Audio for the game"
# jackpot_audio = pygame.mixer.Sound("noise/reward.mp3")
# transaction_audio = pygame.mixer.Sound("noise/win.mp3")

"Choose player to display"
choose = ["Player One", "Player Two", "Player Three", "Player Four", "Player Five", "Player Six"]
player_index = 0

"Jail cell name"
jail_name = "Go to jail"

"stations name"
global_stations = {"Brighton Station", "Hove Station", "Falmer Station", "Portslade Station"}

"Utilities"
global_utilities = {"Edison Water", "Tesla Power Co"}

class Text:
    def __init__(self, x, y, color, font, size):
        self.x = x
        self.y = y
        self.color = color
        self.font = font
        self.size = size

    def create_message(self, screen, message):
        font_name = pygame.font.Font(self.font, self.size)
        text = font_name.render(message, False, self.color, None)
        rect = text.get_rect()
        screen.blit(text, [self.x, self.y])


class image:
    def __init__(self, image, x, y, height, width):
        self.x = x
        self.y = y
        self.image = image
        self.height = height
        self.width = width

    def draw_image(self):
        images = pygame.transform.scale(self.image, (self.height, self.width))
        screen.blit(images, (self.x, self.y))

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def get_x(self):
        return self.x

    def get_y(self):
        return self.x


class button:
    def __init__(self, scree, x, y, width, height, clr, cngclr, func, text, font, font_size, font_clr):
        self.clr = clr
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.func = func
        self.surf = scree
        self.rect = pygame.draw.rect(screen, clr, (self.x, self.y, self.width + 20, self.height + 20))

        self.font = pygame.font.Font(font, font_size)
        self.txt = text
        self.font_clr = font_clr
        self.txt_surf = self.font.render(self.txt, True, self.font_clr)
        self.txt_rect = self.txt_surf.get_rect()
        self.text_width = self.txt_rect.width
        self.text_height = self.txt_rect.height

    def draw(self):
        pygame.draw.rect(screen, self.clr, (self.x - 20, self.y - 10, self.text_width + 30, self.text_height + 20))
        screen.blit(self.txt_surf, self.rect)

    def click(self, screen, x, y):

        if x >= self.x - 15 and x <= self.x + self.text_width + 10:
            if y >= self.y - 15 and y <= self.y + self.text_height + 10:
                return True
        return False

    def hover(self):
        pass

    def change_message(self, message):
        self.txt = message

    def set_font(self, font):
        self.font = font


class rectangle:

    def __init__(self, scr, x, y, width, height, color, thick):
        self.screen = scr
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.color = color
        self.thick = thick
        self.rec = 0
        self.draw()

    def draw(self):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.width, self.height), self.thick)

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def click(self, screen, x, y):

        if x >= self.x - 15 and x <= self.x + self.width + 10:
            if y >= self.y - 15 and y <= self.y + self.height + 10:
                return True
        return False

    def add_text(self, screen, message, size):
        text = Text((self.x + self.width // 2), (self.y + self.height // 2), WHITE, font_1, size)
        text.create_message(screen, message)


def menu():
    class Options:
        def __init__(self, screen, Width, height):
            self.screen = screen
            self.Width = Width
            self.height = height

        def set_width(self, width):
            self.Width = width

        def set_height(self, height):
            self.height = height

        def get_width(self):
            return self.Width

        def get_height(self):
            return self.height

    running = True
    scr = Options(screen, WIDTH, HEIGHT)

    "Button for the screen"
    button1 = button(scr, scr.get_width() // 4.7, 150, WIDTH, HEIGHT, RED, None, None, "Property Tycoon", Fonts, 45,
                     WHITE)
    button3 = button(scr, scr.get_width() // 8, 500, WIDTH, HEIGHT, RED, None, None, "Single Player", Fonts, 30, WHITE)
    button4 = button(scr, scr.get_width() // 1.7, 500, WIDTH, HEIGHT, RED, None, None, "Multi Player", Fonts, 30, WHITE)

    button_arr = [button1, button3, button4]

    background_image_class = image(BACKGROUND_IMAGE, 0, 0, 1000, 790)

    while running:
        background_image_class.draw_image()

        button1.draw()
        button3.draw()
        button4.draw()

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

            if event.type == MOUSEBUTTONDOWN:
                position = pygame.mouse.get_pos()
                if button4.click(screen, position[0], position[1]):
                    define_player(player_index, choose)

        pygame.display.update()
        mainClock.tick(60)


def define_player(player_index, choose):
    class token_gui:
        def __init__(self, token, Height, Width):
            self.token = token
            self.remove = set()
            self.coordinates = []
            self.width = Width
            self.height = Height
            self.selected = []

        def draw_token(self, screen):

            space = 20
            width = (WIDTH - 140) // 3
            x = 70
            y = 210
            index = 0

            second_row_y = y + 250

            top_coordinates = []
            bottom_coordinates = []

            while x < WIDTH and index < 3:
                image_class = image(self.token[index], x, y, self.height, self.width)
                image_class.draw_image()
                top_coordinates.append([x, y])

                image_class2 = image(self.token[index + 3], x, second_row_y, self.height, self.width)
                image_class2.draw_image()
                bottom_coordinates.append([x, second_row_y])
                x += width + space
                index += 1
            self.coordinates += top_coordinates
            self.coordinates += bottom_coordinates

        def remove(self, index):
            pass

        def check(self, index):
            if index in self.remove:
                return False
            return True

        def get_token(self, x, y):
            for i in range(len(self.coordinates)):
                if [x, y] == self.coordinates[i]:
                    return self.token[i]

        def return_coordinates(self):
            return self.coordinates

        def found_rec(self, x, y):
            found = False
            item_coordinates = 0

            for coordinates in self.coordinates:
                token_x = coordinates[0]
                token_y = coordinates[1]
                if x >= token_x - 15 and x <= token_x + self.width + 10:
                    if y >= token_y - 15 and y <= token_y + self.height + 10:
                        item_coordinates = coordinates
                        found = True
                        break

            if found:
                return [item_coordinates[0], item_coordinates[1], self.width, self.height]
            else:
                return []

        def check_selected(self, coordinates):
            if coordinates not in self.selected:
                return True
            return False

        def add(self, coordinates):
            self.selected.append(coordinates)

    "Header"
    # Background = image(BACKGROUND_IMAGE, 0, 0, 1000, 790)

    player_number = button(screen, 70, 100, 50, 50, RED, None, None, choose[player_index], Fonts, 20, WHITE)
    submit_button = button(screen, WIDTH // 2.1, HEIGHT - 50 - 20, 50, 50, RED, None, None, "Submit",
                           Fonts, 20, WHITE)

    done_button = button(screen, WIDTH // 3.1, HEIGHT - 50 - 20, 50, 50, RED, None, None, "Finish",
                         Fonts, 20, WHITE)

    images = [pygame.image.load("images/boot.png"), pygame.image.load("images/cat.png"),
              pygame.image.load("images/hatstand.png"),
              pygame.image.load("images/iron.png"), pygame.image.load("images/ship.png"),
              pygame.image.load("images/smartphone.png"), ]

    "setting the rectangle for the tokens"
    token_active = False
    token_active_color = RED
    token_de_active_color = None
    token_current_color = None
    token_rect_coordinates = []
    token_image = 0
    is_token_chosen = False

    background_image_class = image(BACKGROUND_IMAGE, 0, 0, 1000, 790)

    "Setting the text position"
    font = font1_render
    user_text = ""
    input_rect = pygame.Rect(280, 89, 340, 42)
    color_Active = RED
    color_off = BlACK
    current_color = BROWN
    active = False
    maximum_width = 341
    picked = False
    rect = 0

    " function which refresh the page "

    def refresh_define_player():
        define_player(player_index, choose)

    " Create an instance of a token_gui class"
    token_gui = token_gui(images, 170, 170)
    run = True

    while run:

        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit()
                sys.exit()

            if event.type == MOUSEBUTTONDOWN:
                position = pygame.mouse.get_pos()
                if done_button.click(screen, position[0], position[1]) and len(player_playing_game) > 1:
                    Gui_board()

                if submit_button.click(screen, position[0], position[1]):
                    if is_token_chosen and len(user_text) > 0:
                        player_playing_game[user_text] = token_image
                        player_index += 1
                        if player_index >= len(choose):
                            Gui_board()
                        else:
                            refresh_define_player()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if input_rect.collidepoint(event.pos):
                    active = True
                else:
                    active = False
            if event.type == KEYDOWN and active and input_rect.width <= maximum_width:
                if event.key == pygame.K_BACKSPACE:
                    user_text = user_text[:-1]
                else:
                    user_text += event.unicode

            "Check fo mouse motion"
            if event.type == pygame.MOUSEMOTION:
                mouse_motion_pos = pygame.mouse.get_pos()
                token_shadow = token_gui.found_rec(mouse_motion_pos[0], mouse_motion_pos[1])

                if len(token_shadow) > 0 and picked == False:
                    token_rect_coordinates = token_gui.found_rec(mouse_motion_pos[0], mouse_motion_pos[1])
                elif len(token_shadow) == 0 and picked == False:
                    token_rect_coordinates = []

            if event.type == MOUSEBUTTONDOWN:
                mouse_position = pygame.mouse.get_pos()
                is_token_present = token_gui.found_rec(mouse_position[0], mouse_position[1])
                if len(is_token_present) > 0 and is_token_present not in choosen_coordinaties:
                    choosen_coordinaties.append(is_token_present)
                    picked = True

        screen.fill(BOARD_COLOR)

        "Text operations"
        if active:
            current_color = color_Active
        if not active:
            current_color = color_off
        text_surface = font.render(user_text, True, WHITE)
        pygame.draw.rect(screen, current_color, input_rect)
        screen.blit(text_surface, (input_rect.x, input_rect.y))
        if active:
            if text_surface.get_width() - 4 >= input_rect.width and input_rect.width < maximum_width:
                input_rect.w = max(100, input_rect.width + 10)

        "Rectangle around the token"
        if len(token_rect_coordinates) > 0 and not picked and token_rect_coordinates not in choosen_coordinaties:
            rect = rectangle(screen, token_rect_coordinates[0], token_rect_coordinates[1], token_rect_coordinates[2],
                             token_rect_coordinates[3], token_active_color, 0)

            rect.draw()
        if picked:
            token_image = token_gui.get_token(token_rect_coordinates[0], token_rect_coordinates[1])
            is_token_chosen = True
            rect.draw()

        "Set the color of being active and not active"
        player_number.draw()
        submit_button.draw()
        done_button.draw()

        token_gui.draw_token(screen)

        pygame.display.update()
        pygame.display.flip()
        mainClock.tick(60)


def Gui_board():
    class GameBoard:
        def __init__(self, board, x, y, color):
            self.board = board
            self.x = x
            self.y = y
            self.color = color
            self.coordinates = []
            self.cell_items = {}
            self.Width = float("inf")
            self.Height = float("inf")

        def draw_screen(self, screen, rect):

            horizontal_height = 80
            horizontal_width = (self.x // 10)
            start_x = 0
            start_top_y = 1
            border_thickness = 4

            # horizontal_top_cell
            h_top = []
            # horizontal_bottom_cell
            h_bottom = []
            # vertical_left_cell
            v_left = []
            # vertical_right_cell
            v_right = []

            "Store the rectangle for further modification"
            cells = []
            h_top_cell = []
            h_bottom_cell = []
            v_left_cell = []
            v_right_cell = []

            start_bottom_y = self.y - horizontal_height - 1
            while start_x < self.x:
                "Top cells"
                top_rectangle = rect(screen, start_x, start_top_y, horizontal_width, horizontal_height, self.color,
                                     border_thickness)

                top_rectangle.draw()
                h_top.append((start_x, start_top_y))
                h_top_cell.append(top_rectangle)

                "Bottom cells"
                bottom_rectangle = rect(screen, start_x, start_bottom_y, horizontal_width, horizontal_height,
                                        self.color,
                                        border_thickness)
                bottom_rectangle.draw()
                h_bottom.append((start_x, start_bottom_y))
                h_bottom_cell.append(bottom_rectangle)

                start_x += horizontal_width

            "Vertical cells"
            Vertical_height = (self.y - (horizontal_height * 2)) // 10
            vertical_width = horizontal_width

            v_start = horizontal_height

            right_position = self.x - vertical_width

            while v_start + horizontal_height < self.y:
                left_rectangle = rect(screen, 0, v_start, vertical_width, Vertical_height, self.color, border_thickness)
                v_left.append((0, v_start))
                v_left_cell.append(left_rectangle)

                right_rectangle = rect(screen, right_position, v_start, vertical_width, Vertical_height, self.color,
                                       border_thickness)
                right_rectangle.draw()

                v_right.append((right_position, v_start))
                v_start += Vertical_height
                v_right_cell.append(right_rectangle)
            h_bottom.reverse()
            v_left.reverse()

            "Add the cell coordinates in order to the self.coordinates array"
            self.coordinates += h_top
            self.coordinates += v_right
            self.coordinates += h_bottom
            self.coordinates += v_left

            h_bottom_cell.reverse()
            v_left_cell.reverse()
            cells += h_top_cell
            cells += v_right_cell
            cells += h_bottom_cell
            cells += v_left_cell

            self.Width = horizontal_width
            self.Height = min(Vertical_height, horizontal_height)
            self.set_cell_name_positions()

            "Iterate through both the board and the cells and apply the color of the group"
            i = 0
            current = self.board.get_head()
            head = current

            while current:
                if current.next == head:
                    break
                else:
                    if self.board.is_it_property(current.val):
                        cell_property = current.property
                        cell_rectangle = cells[i]
                        if cell_property.get_group() != "":
                            cell_rectangle.color = cell_property.get_group()
                            cell_rectangle.draw()
                current = current.next
                i += 1

            if self.board.is_it_property(current.val):
                cell_property = current.property
                cell_rectangle = cells[i]
                if cell_property.get_group() != "":
                    cell_rectangle.color = cell_property.get_group()
                    cell_rectangle.draw()

        def increment(self, index):
            return [self.coordinates[index][0], self.coordinates[index][1]]

        def get_player_position(self, cell_name):
            return self.cell_items[cell_name]

        def set_cell_name_positions(self):
            items = self.board.get_cell_items()
            for i in range(0, 40):
                self.cell_items[items[i + 1]] = self.coordinates[i]

        def draw_cells_item(self, screen):
            items = self.board.get_cell_items()
            for i in range(40):
                cell_location = self.coordinates[i]
                cell_name = Text(cell_location[0] + 10, cell_location[1] + 20, RED, font_1, 20)
                cell_name.create_message(screen, items[i + 1])

        def get_width(self):
            return self.Width

        def get_height(self):
            return self.Height

        def increment_by_name(self, cell_name):
            return self.cell_items[cell_name]

        def return_coordinates(self, arr):
            return self.coordinates.index(arr)

    class dice:
        def __init__(self, pictures, x, y, width, height):
            self.pictures = pictures
            self.x = x
            self.y = y
            self.width = width
            self.height = height

        # function that take an index and get the image from the pcitures and blit on the screen
        def draw(self, screen, index):
            image = self.pictures[index - 1]
            image = pygame.transform.scale(image, (self.width, self.height))
            screen.blit(image, (self.x, self.y))

    "Player class and operation etc..."

    class players_class:
        def __init__(self, player_token, players):
            "jhon : picture"
            self.player_token = player_token
            " name: the class of the player "
            self.players = players

        def set_player(self, player_name, info):
            self.players[player_name] = info

        def get_player(self, player_name):
            return self.players[player_name]

        def get_player_token(self, player_name):
            return self.player_token[player_name]

    def create_players(player_token, current_position, start_point):
        new_players = {}
        for person_name in player_token:
            new_players[person_name] = PlayerInformation(person_name, player_token[person_name], current_position,
                                                         False, start_point)
        return new_players

    def add_players_to_game(player_token, player_loop):
        for person_name in player_token:
            player_loop.add(person_name)

    "Putting property in mortgage"

    def property_removal(world_bank, rent, current_player):
        current_rent = rent
        while current_player.get_balance() < current_rent:
            "Remove the property from the current player"
            """ add the property to the mortgage of the bank and the users """
            "Add the mortage value to the current player balance"
            mortgage_property = current_player.get_property().select_property()
            if mortgage_property == 0 and current_player.get_balance() < current_rent:
                return False

            current_player.get_property().remove_property(mortgage_property)
            current_player.get_property().add_to_mortgage(mortgage_property)
            world_bank.add_mortgage(mortgage_property)

            value = world_bank.mortgage(mortgage_property)
            current_player.deposit(value)
        return True

    "Sell the property to the bank function"

    def property_sell_to_bank(world_bank, current_player, rent):
        current_rent = rent
        while current_player.get_balance() < current_rent:

            sell_the_property = current_player.get_property().get_mortgage()
            if sell_the_property == 0 and current_player.get_balance() < current_rent:
                return False
            if sell_the_property.get_name() in global_stations:
                current_player_station = current_player.get_stations()
                current_player_station.decrement_rent()
            if sell_the_property.get_name() in global_utilities:
                current_player_utility = current_player.get_utility()
                current_player_utility.remove_utility()

            current_player.get_property().remove_mortgage(sell_the_property)
            world_bank.remove_mortgage(sell_the_property)
            world_bank.get_own_bank_properties().add(sell_the_property)

            value = sell_the_property.get_cost()
            world_bank.withdraw(value)
            current_player.deposit(value)
        return True

    "Auction class checking whether he passed go"

    def auction_participants(auction_player_list, players):
        length = players.length()
        curr = players
        while length > 0 and curr:
            current_player_in_game = curr.val
            if current_player_in_game.get_go():
                auction_player_list.add(current_player_in_game)
            curr = curr.next
        return auction_player_list

    run = True
    " Board GUI and its operation "
    Board = board()
    Board.add_property_class_to_cell()
    Board.assign_cell_name()
    first_index = Board.get_head()
    GameBoard = GameBoard(Board, WIDTH, HEIGHT, BlACK)
    name = button(screen, screen.get_width() // 4.7, 300, WIDTH, HEIGHT, RED, None, None, "Property Tycoon", Fonts, 40,
                  WHITE)

    "Bank "
    world_bank = Bank(50000)

    "Player operation and etc .."
    "Test these classes to ensure they are working correctly ------ ----- "

    "People who is playing the game"
    game_players = CurrentPlaying()
    "Player personal information"
    all_player_info = create_players(player_playing_game, 0, first_index)
    "connect the token with player class"
    player_information_class = players_class(player_playing_game, all_player_info)
    add_players_to_game(player_playing_game, game_players)
    "The current player who is playing now"
    current_player = 0
    current_player_name = ""
    display_name = Text(screen.get_width() // 2.4, 100, BlACK, font_1, 60)
    next_player_button = button(screen, screen.get_width() // 2.6, 250, WIDTH, HEIGHT, SKY_BLUE, None, None,
                                "Next Player", Fonts, 20, BlACK)

    "Income tax and super tax"
    parking_class = FreeParking(Board.get_cell_name_node("Free Parking"))
    income_tax = 200
    income_tax_cell = Board.get_cell_name_node("Income Tax")
    super_tax = 100
    super_tax_cell = Board.get_cell_name_node("Super Tax")

    "Jail class and its operations"
    jail = JailCell()
    jail_position = Board.get_cell_name_node("Go to Jail")
    just_visiting_jail = "Jail/Just visiting"

    "Dice operation, object etc..."
    turn_button = button(screen, screen.get_width() // 2.3, 200, WIDTH, HEIGHT, SKY_BLUE, None, None, "Roll", Fonts, 20,
                         BlACK)
    dices_image = [pygame.image.load("images/one.PNG"), pygame.image.load("images/two.PNG"),
                   pygame.image.load("images/three.PNG"), pygame.image.load("images/four.PNG"),
                   pygame.image.load("images/five.PNG"), pygame.image.load("images/six.PNG")]
    dice_class = Dice()
    dice_one_pygame = dice(dices_image, 300, 184, 50, 50)
    dice_two_pygame = dice(dices_image, 570, 184, 50, 50)
    roll1 = 1
    roll2 = 1
    select_player = False
    select_next_player = False
    can_roll_dice = False

    "PotLuck and Opportunity Knocks"

    opportunity_knock_class = Opportunity()
    isopportunity = False
    opportunity_tokens = opportunityknock(200, 240, 150, 420)
    opp_token = opportunity_tokens.front_page()

    potluck_class = potluck()
    ptoken = potlucktoken(200, 240, 650, 420)
    ispotluck = False
    token = ptoken.front_page()

    "Options such as sell,buy, rent etc.... "
    # Build a rectangle class which will include different texts
    OPTIONS_WIDTH = 550
    OPTIONS_HEIGHT = 350
    OPTION_X = 210
    OPTION_Y = 200
    general_rectangle = rectangle(screen, OPTION_X, OPTION_Y, OPTIONS_WIDTH, OPTIONS_HEIGHT, BlACK, 0)

    OPTION_BUTTON_WIDTH = 50
    OPTION_BUTTON_HEIGHT = 90

    Text_size = 40

    "Text for all the options"
    buy_text = "Do you want to buy the property?"
    property_name = "Property: "
    property_worth = "Worth:"
    buy_congrats_text = "you have successfully bought the property"

    auction_welcome_text = "Auction"
    auction_header_text = "Highest bid : "
    player_name = "Name"
    auction_bid = "Bid"

    rent_text = "pay rent for the property"
    rent_property_text = "Property : "
    rent_rent_text = "rent : "
    rent_not_enough_rent = " insufficient amount of money"

    sell_decision = "Do you want to sell the property"
    sell_property_text = "Property :"
    sell_worth_text = "Worth :"
    sell_button_text = "Sell"

    " In this portion of the code we will create all the option screens "

    class option:
        def __init__(self, rect, x, y):
            self.rect = rect
            self.x = x
            self.y = y
            self.done = False

        def draw_screen(self):
            " Draw the rect on the screen "
            self.rect.draw()

        def draw_text(self, screen, text, x, y, size):
            words = Text(x, y, WHITE, font_1, size)
            words.create_message(screen, text)

        def is_done(self):
            if self.done:
                return True
            return False

        def set_done(self, isdone):
            self.done = isdone

        def get_x(self):
            return self.x

        def get_y(self):
            return self.y

    #  def passed_go(self,player):

    "Options all the different pop up pages such as buying property, renting property and selling"
    buy_property = option(general_rectangle, 210, 200)

    buy_yes = button(screen, buy_property.x + (OPTIONS_WIDTH // 2.8), buy_property.y + OPTIONS_HEIGHT - 100,
                     OPTION_BUTTON_WIDTH, OPTION_BUTTON_HEIGHT, RED, None,
                     None, "Yes", font_1, Text_size, WHITE)
    buy_no = button(screen, buy_property.x + (OPTIONS_WIDTH // 1.9), buy_property.y + OPTIONS_HEIGHT - 100,
                    OPTION_BUTTON_WIDTH, OPTION_BUTTON_HEIGHT, RED, None,
                    None, "No", font_1, Text_size, WHITE)
    buy_click = False

    property_auction_class = Auctions(None)
    property_auction = option(general_rectangle, 210, 200)

    auction_list = CurrentPlaying()

    "Setting the text position of auction"
    auction_font = font1_render
    auction_user_text = ""
    auction_input_rect = pygame.Rect(buy_property.y + 120, buy_property.x + 180, 200, 35)
    auction_color_Active = RED
    auction_color_off = SKY_BLUE
    auction_current_color = BROWN
    auction_active = False
    auction_maximum_width = 100
    auction_picked = False
    auction_rect = 0
    auction_submit = button(screen, buy_property.x + 150 + 205, buy_property.y + 190,
                            30, 35, SKY_BLUE, None,
                            None, "Submit", font_1, Text_size - 15, BlACK)

    auction_price = 0
    current_auction_player = 0
    current_auction_player_name = ""
    num_participant = 0
    current_auction_property = None

    sell_property = option(general_rectangle, 210, 200)
    sell_yes = button(screen, buy_property.x + (OPTIONS_WIDTH // 3.6), buy_property.y + OPTIONS_HEIGHT - 100,
                      OPTION_BUTTON_WIDTH, OPTION_BUTTON_HEIGHT, RED, None,
                      None, "Yes", font_1, Text_size, WHITE)

    rent_property = option(general_rectangle, 10, 200)
    rent_yes = button(screen, buy_property.x + (OPTIONS_WIDTH // 2), buy_property.y + OPTIONS_HEIGHT - 100,
                      OPTION_BUTTON_WIDTH, OPTION_BUTTON_HEIGHT, RED, None,
                      None, "Yes", font_1, Text_size, WHITE)

    "Player tokens"
    player_six = 0
    player1_token = None
    x_player = 0
    y_player = 0
    position = 0

    "Scenes"
    scene_stack = []
    while run:
        "Draw all the necessary component on the Board "
        screen.fill(BOARD_COLOR)
        GameBoard.draw_screen(screen, rectangle)
        name.draw()
        turn_button.draw()
        Board.assign_cell_name()
        GameBoard.draw_cells_item(screen)
        next_player_button.draw()

        for event in pygame.event.get():

            if event.type == QUIT:
                pygame.quit()
                sys.exit()

            "Turn button click roll the dice"
            if event.type == KEYDOWN and auction_active and property_auction.is_done():
                if event.key == pygame.K_BACKSPACE:
                    auction_user_text = auction_user_text[:-1]
                else:
                    digit = event.unicode
                    if digit.isdigit():
                        auction_user_text += event.unicode
            if event.type == pygame.MOUSEBUTTONDOWN:
                position = pygame.mouse.get_pos()

                if auction_input_rect.collidepoint(position):
                    auction_active = True
                    print(auction_active)
                else:
                    auction_active = False

                if buy_yes.click(screen, position[0],
                                 position[1]) and buy_property.is_done() and current_player.get_go():
                    "Check if it landed on property"
                    player_node = current_player.get_position_node()
                    board_property = player_node.property

                    print(current_player.get_name(), "before Balance: ", current_player.get_balance())
                    property_cost = 0

                    if board_property.get_name() in global_stations:
                        player_station = current_player.get_stations()
                        player_station.increment_rent()

                    if board_property.get_name() in global_utilities:
                        player_utility = current_player.get_utility()
                        player_utility.add_utility()

                    property_cost = board_property.get_cost()

                    if property_cost <= current_player.get_balance():
                        # print(f"{current_player.get_name()} bought the property")
                        Board.set_belong(player_node, current_player)
                        current_player.withdraw(board_property.get_cost())
                        world_bank.deposit(board_property.get_cost())
                        buy_property.set_done(False)
                        "Remove the property from the bank, and add to the player"
                        world_bank.sell_property(board_property.get_name())
                        individual_properties = current_player.get_property()
                        individual_properties.add_property(board_property)

                        print(current_player.get_name(), "after Balance: ", current_player.get_balance())
                       # transaction_audio.play()


                    elif board_property.get_cost() > current_player.get_balance():
                        print("you have insufficent amount of money")

                    if scene_stack:
                        scene_stack.pop()

                elif buy_no.click(screen, position[0],
                                  position[1]) and buy_property.is_done() and current_player.get_go():

                    buy_property.set_done(False)
                    if scene_stack:
                       scene_stack.pop()
                    print(f"{current_player.get_name()} didn't buy the property, so it went into the auction")
                    auction_price = current_auction_property
                    property_auction.set_done(True)
                    scene_stack.append(property_auction)

                    auction_players = game_players
                    head_player_name = auction_players.turn()

                    auction_players.next_turn()
                    auction_player_turn = player_information_class.get_player(auction_players.turn())

                    while auction_players.turn() != head_player_name:

                        if auction_player_turn.get_go():
                            if current_auction_player_name == "":
                                current_auction_player_name = auction_player_turn.get_name()
                                property_auction.draw_text(screen, f"{current_auction_player_name} ",
                                                           (OPTION_X + (OPTIONS_WIDTH // 2.5)),
                                                           OPTION_Y + 240, Text_size + 5)

                            print(auction_player_turn.get_name())
                            num_participant += 1
                            auction_list.add(auction_player_turn)

                        auction_players.next_turn()
                        auction_player_turn = player_information_class.get_player(auction_players.turn())
                    if num_participant == 0:
                        property_auction.set_done(False)
                        scene_stack.pop()

                    "Check if you landed on the rent option "
                elif rent_yes.click(screen, position[0],
                                    position[1]) and current_player.get_go() and buy_property.is_done() == False:
                    player_node = current_player.get_position_node()
                    board_property = player_node.property
                    current_player.get_balance()
                    property_belong_player = player_node.belong
                    global_rent = 0

                    if board_property.get_name() in global_stations:
                        player_station = property_belong_player.get_stations()
                        global_rent = player_station.get_rent()
                        print("station rent is: ", global_rent)

                    if board_property.get_name() in global_utilities:
                        player_utility = property_belong_player.get_utility()
                        global_rent = player_utility.total_rent(roll1, roll2)
                        print("utility rent is :", global_rent)


                    else:
                        global_rent = board_property.get_rent()

                    "This is if statement check if player has enough money he can pay the rent "
                    if global_rent <= current_player.get_balance():
                        current_player.withdraw(board_property.get_rent())
                        print(f"{current_player.get_name()} paid his rent")
                        property_belong_player.deposit(board_property.get_rent())
                        rent_property.set_done(False)
                        #transaction_audio.play()
                    elif global_rent > current_player.get_balance():
                        player_personal_properties = current_player.get_property()
                        "Check if the user have property to mortgage"
                        if property_removal(world_bank, global_rent, current_player):
                            current_player.withdraw(global_rent)
                            print(f"{current_player.get_name()} paid his rent")
                            property_belong_player.deposit(global_rent)
                            rent_property.set_done(False)
                            #transaction_audio.play()

                            "check if he has properties to sell "
                        elif property_sell_to_bank(world_bank, current_player, global_rent):
                            current_player.withdraw(global_rent)
                            print(f"{current_player.get_name()} paid his rent")
                            property_belong_player.deposit(global_rent)
                            rent_property.set_done(False)
                           # transaction_audio.play()

                            "If he has no property to mortgage and sell, the player out of the game"
                        else:
                            player_playing_game.pop(current_player.get_name())
                            game_players.delete(current_player)
                            print(f"{current_player.get_name()} is out of the game")
                            rent_property.set_done(False)
                    print("player balance: {}".format(current_player.get_balance()))

                    if scene_stack:
                        scene_stack.pop()


                elif auction_submit.click(screen, position[0], position[1]) and auction_user_text.isdigit():
                    current_auction_player = auction_list.turn()
                    current_auction_player_name = current_auction_player.get_name()
                    property_auction.draw_text(screen, current_auction_player_name, (OPTION_X + (OPTIONS_WIDTH // 2.5)),
                                               (OPTION_Y + 240), Text_size)
                    bet_amount = int(auction_user_text)
                    if (bet_amount > auction_price) and (current_auction_player.get_balance() >= bet_amount):
                        auction_price = bet_amount
                        property_auction_class.set_highest_bidder(current_auction_player)
                        property_auction_class.set_bid_price(auction_price)

                    elif (bet_amount <= auction_price) or (bet_amount > auction_price and current_auction_player.get_balance() < bet_amount):
                        auction_list.delete(current_auction_player_name)

                    if auction_list.length() == 0:
                        highest_bidder =  property_auction_class.get_highest_bidder()
                        highest_bid =   property_auction_class.get_bid_price()
                        if highest_bidder is None:
                            print("the property went to the bank")

                        else:
                            highest_bidder.withdraw(highest_bid)
                            world_bank.deposit(highest_bid)
                            print("the auction won by : ", highest_bidder.get_name())

                        property_auction.set_done(False)
                        scene_stack.pop()
                        auction_list = CurrentPlaying()

                    " Refresh the content of the auction page "
                    if property_auction.is_done() and current_auction_player.get_balance() > auction_price:
                        auction_list.next_turn()
                        auction_user_text = ""
                        text_surface = auction_font.render(auction_user_text, True, BlACK)
                        pygame.draw.rect(screen, auction_current_color, auction_input_rect)
                        screen.blit(text_surface, (auction_input_rect.x, auction_input_rect.y))

                        current_auction_player = auction_list.turn()
                        current_auction_player_name = current_auction_player.get_name()
                        property_auction.draw_text(screen, current_auction_player_name, (OPTION_X + (OPTIONS_WIDTH // 2.5)),
                                               (OPTION_Y + 240), Text_size)


                elif next_player_button.click(screen, position[0], position[1]) and not select_next_player and len(
                        scene_stack) == 0 and not can_roll_dice:


                    game_players.next_turn()
                    current_player = player_information_class.get_player(game_players.turn())
                    axis = GameBoard.increment(current_player.get_position())
                    position = current_player.get_position()
                    x_player = axis[0]
                    y_player = axis[1]
                    current_player_name = current_player.get_name()

                    player1_token = image(current_player.get_token(), x_player, y_player, 50, 50)
                    select_next_player = True
                    select_player = True
                    can_roll_dice = True
                    player_six = 0

                    # Check if he is in jail and check if he has jail free card, if he has it use it .
                    if jail.check_player(current_player.get_name()) == True:
                        paid = False
                        "check if he has jail free card"
                        if current_player.check():
                            paid = True
                            current_player.remove_card()
                            "if player doesn't have jail free card, pay the bail money"
                        elif not current_player.check():
                            val = current_player.withdraw(jail.get_fine())
                            jail.get_fine()
                            if val == jail.get_fine():
                                if not current_player.get_go():
                                    current_player.set_position_move_back(11)
                                paid = True
                        "if he paid his bail, move player to jail free cell"
                        if paid:
                            jail.remove_player(current_player.get_name())
                            current_player.set_position_node(Board.get_cell_name_node(just_visiting_jail))
                            index_position = GameBoard.increment_by_name(just_visiting_jail)
                            x_player = index_position[0]
                            y_player = index_position[1]
                            current_player.set_position(GameBoard.return_coordinates(index_position))

                        "if he doesn't have enough money and jail free card, then the mortgage or sell his properties"
                    # if not paid:

                    "setting the gui to its beginning state"
                    token = ptoken.front_page()
                    opp_token = opportunity_tokens.front_page()



                elif turn_button.click(screen, position[0], position[1]) and select_player and len(
                        scene_stack) == 0 and can_roll_dice:

                    "Get random dice number"
                    roll_num = dice_class.random_number()
                    roll_num2 = dice_class.random_number()
                    roll1 = roll_num
                    roll2 = roll_num2

                    "Update the current player position on the gui board"
                    next_position = (current_player.get_position() + roll1 + roll2) % 40
                    current_player.set_position(next_position)
                    player_information_class.set_player(current_player.get_name(), current_player)
                    axis = GameBoard.increment(next_position)
                    x_player = axis[0]
                    y_player = axis[1]
                    select_next_player = False
                    can_roll_dice = False

                    "Check if turn got three sixes"
                    if roll1 == roll2:
                        can_roll_dice = True
                        player_six += 1

                    "Update the logic board"
                    position_node = Board.increment(current_player.get_position_node(), roll1 + roll2)
                    current_player.set_position_node(position_node)
                    'Check if he passed go twice'
                    current_player.set_position_move(roll1 + roll2)

                    if current_player.get_position_move() > 40:
                        if not current_player.get_go():
                            current_player.set_go()
                        print(current_player.get_position_move())
                        moves = current_player.get_position_move() % 40
                        current_player.set_position_move_back(moves)
                        print(current_player.get_position_move())
                        print("set_position")
                        print("Balance before : ", current_player.get_balance())
                        current_player.deposit(200)
                        world_bank.withdraw(200)
                        print("Balance after : ", current_player.get_balance())

                    if current_player.get_go():

                        player_node = current_player.get_position_node()
                        if Board.is_it_property(player_node.val):
                            board_property = player_node.property
                            if player_node.belong is None:
                                buy_property.set_done(True)
                                scene_stack.append(buy_property)
                                current_auction_property = board_property.get_cost()
                            elif position_node.belong is not None and world_bank.check_mortgage(
                                    board_property) == False:
                                rent_property.set_done(True)
                                scene_stack.append(rent_property)

                            "Check if you landed on opportunity or pot luck"
                        elif opportunity_knock_class.check_board_activation(next_position):
                           # pygame.mixer.Sound.play(jackpot_audio)
                            isopportunity = True
                        elif potluck_class.check_board_activation(next_position):
                          #  pygame.mixer.Sound.play(jackpot_audio)
                            ispotluck = True

                        "Check if they landed on super tax or income tax"
                    if position_node == income_tax_cell or position_node == super_tax_cell:
                        if income_tax_cell == position_node:
                            value = current_player.withdraw(income_tax)
                            parking_class.add_to_balance(value)
                        elif super_tax_cell == position_node:
                            value = current_player.withdraw(super_tax)
                            parking_class.add_to_balance(value)
                    if position_node == parking_class.get_position():
                        current_player.deposit(parking_class.get_balance())
                        "Check if he landed in jail"
                    if position_node == jail_position:
                        jail.add_player(current_player.get_name())

                    if player_six == 3:
                        jail.add_player(current_player.get_name())
                        player_six = 0
                    auction_price = 0
                    auction_user_text = ""
                    current_auction_player_name = ""

        "Update the dice variable"
        if player1_token is not None:
            player1_token.set_x(x_player + 10)
            player1_token.set_y(y_player)
            player1_token.draw_image()

        if isopportunity:
            opportunity_card = opportunity_knock_class.dequeue()
            isopportunity = False
            opp_token = opportunity_tokens.dequeue()

            "Check if we landed on the cell of OpportunityKnock"
            opp_operation = opportunity_knock_class.card_operation(world_bank, current_player, opportunity_card,
                                                                   parking_class)
            if type(opp_operation) == str:
                opportunityk_player_position_move = current_player.get_position_move()
                opportunityk_player_position = current_player.get_position()
                a = GameBoard.increment_by_name(opp_operation)
                b = Board.get_cell_name_node(opp_operation)
                current_player.set_position_node(opp_operation)
                current_player.set_position(GameBoard.return_coordinates(a))
                x_player = a[0]
                y_player = a[1]
                "Update the logic board"
                current_player.set_position_node(b)
                "Update  position_move variable"
                if opp_operation == jail_name:
                    num_moves = 40 - opportunityk_player_position
                    current_player.set_position_move(num_moves)

                elif current_player.get_position() < opportunityk_player_position:
                    num_moves = (40 - opportunityk_player_position) + current_player.get_position()
                    current_player.set_position_move(num_moves)


                elif current_player.get_position() > opportunityk_player_position:
                    current_player.set_position_move(current_player.get_position() - opportunityk_player_position)

        elif ispotluck:
            potluck_card = potluck_class.dequeue()
            token = ptoken.dequeue()

            k = potluck_class.card_operation(world_bank, current_player, potluck_card)
            if type(k) == str:
                pot_luck_player_position_move = current_player.get_position_move()
                pot_luck_player_position = current_player.get_position()
                a = GameBoard.increment_by_name(k)
                b = Board.get_cell_name_node(k)
                current_player.set_position_node(k)
                current_player.set_position(GameBoard.return_coordinates(a))
                x_player = a[0]
                y_player = a[1]
                "Update the logic board"
                current_player.set_position_node(b)

                "Update  position_move variable"
                if pot_luck_player_position == jail_name:
                    num_moves = 40 - pot_luck_player_position
                    current_player.set_position_move(num_moves)
                elif current_player.get_position() < pot_luck_player_position:
                    num_moves = (40 - pot_luck_player_position) + current_player.get_position()
                    current_player.set_position_move(num_moves)


                elif current_player.get_position() > pot_luck_player_position:
                    current_player.set_position_move(current_player.get_position() - pot_luck_player_position)

            ispotluck = False
        ptoken.display_token(screen, token)
        opportunity_tokens.display_token(screen, opp_token)

        "Update the dice"
        dice_one_pygame.draw(screen, roll1)
        dice_two_pygame.draw(screen, roll2)
        display_name.create_message(screen, current_player_name)

        "If user lands on a property to buy? "
        if buy_property.is_done():
            buy_property.draw_screen()
            property_node = current_player.get_position_node().property
            buy_property.draw_text(screen, buy_text, (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 20, Text_size)
            buy_property.draw_text(screen, f"{property_name} : {property_node.get_name()}",
                                   (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 90, Text_size)
            buy_property.draw_text(screen, f"{property_worth} : {property_node.get_cost()}",
                                   (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 150, Text_size)
            buy_yes.draw()
            buy_no.draw()

        "if user plans to sell the property"
        if sell_property.is_done():
            sell_property.draw_screen()
            sell_property.draw_text(screen, sell_decision, (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 20, Text_size)
            sell_property.draw_text(screen, property_name, (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 90, Text_size)
            sell_property.draw_text(screen, property_worth, (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 150,
                                    Text_size)
            sell_yes.draw()

        "if user lands on a players property"
        if rent_property.is_done():
            rent_property.draw_screen()
            property_node = current_player.get_position_node().property
            sell_property.draw_text(screen, f"{rent_text}", (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 20, Text_size)
            sell_property.draw_text(screen, "{} : {}".format(rent_property_text, property_node.get_name()),
                                    (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 90,
                                    Text_size)
            sell_property.draw_text(screen, "{} : {}".format(rent_rent_text, property_node.get_rent()),
                                    (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 150,
                                    Text_size)
            rent_yes.draw()

        if property_auction.is_done():
            property_auction.draw_screen()
            property_node = current_player.get_position_node().property
            property_auction.draw_text(screen, f"{auction_welcome_text}", (OPTION_X + (OPTIONS_WIDTH // 2.8)),
                                       OPTION_Y + 20, Text_size)
            sell_property.draw_text(screen, "property : {}".format(property_node.get_name()),
                                    (OPTION_X + (OPTIONS_WIDTH // 5)), OPTION_Y + 90,
                                    Text_size - 5)
            property_auction.draw_text(screen, f"{auction_bid} : {auction_price}", (OPTION_X + (OPTIONS_WIDTH // 5)),
                                       OPTION_Y + 135, Text_size - 5)

            property_auction.draw_text(screen, f"{current_auction_player_name} ", (OPTION_X + (OPTIONS_WIDTH // 2.5)),
                                       OPTION_Y + 240, Text_size + 5)

            if auction_active:
                auction_current_color = auction_color_Active
            if not auction_active:
                auction_current_color = auction_color_off
            text_surface = auction_font.render(auction_user_text, True, BlACK)
            pygame.draw.rect(screen, auction_current_color, auction_input_rect)
            auction_submit.draw()
            if auction_active:
                if text_surface.get_width() - 4 >= auction_input_rect.width and auction_input_rect.width < auction_maximum_width:
                    auction_input_rect.w = max(100, auction_input_rect.width + 10)
            screen.blit(text_surface, (auction_input_rect.x, auction_input_rect.y))

        pygame.display.update()
        mainClock.tick(60)
menu()
"""
Property Development:

Once a user have all property of the same group color they can develop the houses on the properties if have money 
else: 
    
1: A property can be sold when there is no houses  or hotels on the property.
2: A player may also sell the houses  and hotels to the bank for the original purchase price.

Steps:
   - Create a class that basically shows which shows  properties that  belongs to the same group.
"""
