from PlayersPersonalInformation import PlayerInformation
from Board import board

class PlayerInformationTest:
    def __init__(self):
        self.board = self.board
        self.information = PlayerInformation("jhon", "", (0, 0), False, self.board.head)

    "check the name is properly added"

    def check_name(self):
        assert not self.information.get_name() != "jhon", " The name hasn't properly added"
        print("The name has properly added")

    "checking the position of the player"

    def position(self):
        assert not self.information.get_position_node() != self.board.head, "the initial position is added correctly"
        print("The position has successfully added")

    "check weather the station "
    def station(self):
        assert not self.station() != 0, "The station should be set correctly"
        print("The position is set correctly")

    "check weather go is set to True"
    def check_go(self):
        assert not self.information.get_go() != False, "the go is set unsucessfully"
        print("The file has been set successfully")
