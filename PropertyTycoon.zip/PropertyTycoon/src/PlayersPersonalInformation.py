import PlayerProperties
import Utility
from Board import board
from stations import personal_station
class PlayerInformation:
    def __init__(self, player_name, token, current_position, Go, current_position_node):
        self.balance = 1500
        self.name = player_name
        self.token = token
        self.current_position = current_position
        self.current_node = current_position_node
        self.Go = Go
        self.Player_properties = PlayerProperties.PlayerProperties()
        self.utilities = Utility.Utility()
        self.jail_free = 0
        self.position_move = 0
        self.stations = personal_station()


    def get_utility(self):
        '''

        :return: returns the utilities
        '''
        return self.utilities

    def get_stations(self):
        '''

        :return: returns the station
        '''
        return self.stations

    def get_position_move(self):
        return self.position_move

    def set_position_move(self, count):
        self.position_move += count

    def set_position_move_back(self, count):
        self.position_move = count

    def get_property(self):
        return  self.Player_properties

    def set_property(self,personal_property):
        self.Player_properties = personal_property

    def add_card(self):
        self.jail_free += 1

    def check(self):
        return self.jail_free > 0

    def remove_card(self):
        self.jail_free -= 1

    def set_go(self ):
        self.Go = True

    def get_go(self):
        return self.Go

    def withdraw(self, amount):
        if self.balance - amount >= 0:
            self.balance -= amount
            return amount
        elif self.balance - amount <= 0:
            print("You have no sufficient amount of money")

    def get_name(self):
        return self.name

    def get_token(self):
        return self.token

    def deposit(self, amount):
        self.balance += amount

    def get_balance(self):
        return self.balance

    def set_position(self, position):
        self.current_position = position

    def get_position(self):
        return self.current_position

    def get_position_node(self):
        return self.current_node

    def set_position_node(self,node):
        self.current_node = node
