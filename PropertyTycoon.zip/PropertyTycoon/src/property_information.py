from Property import EachProperty


class PropertyInfo:
    def __init__(self):
        self.each_properties_class = {
            "The Old Creek": EachProperty("The Old Creek", (204, 102, 0), 2, 60, [2, 10, 30, 90, 160, 250]),
            "Gangsters Paradise": EachProperty("Gangsters Paradise", (204, 102, 0), 4, 60, [4, 20, 60, 180, 320, 450]),
            "The Angels Delight": EachProperty(" The Angels Delight", (0, 0, 255), 6, 100, [30, 90, 270, 400, 550]),
            "Potter Avenue": EachProperty("Potter Avenue", (0, 0, 255), 6, 100, [30, 90, 270, 400, 550]),
            "Granger Drive": EachProperty("Granger Drive", (0, 0, 255), 8, 120, [40, 100, 300, 450, 600]),
            "Skywalker Drive": EachProperty("Skywalker Drive", (255, 0, 255), 10, 140, [50, 150, 450, 625, 750]),
            "Wookie Hole": EachProperty("Wookie Hole", (255, 0, 255), 10, 140, [50, 150, 450, 625, 750]),
            "Rey Lane": EachProperty("Rey Lane", (255, 0, 255), 12, 160, [180, 500, 700, 900]),
            "Bishop Drive": EachProperty("Bishop Drive", (225, 178, 102), 14, 180, [70, 200, 550, 750, 950]),
            "Dunham Street": EachProperty("Dunham Street", (225, 178, 102), 14, 180, [70, 200, 550, 750, 950]),
            "Broyles Lane": EachProperty("Broyles Lane", (225, 178, 102), 16, 200, [80, 220, 600, 800, 1000]),
            "Yue Fei Square": EachProperty("Yue Fei Square", (225, 17, 0), 18, 220, [90, 250, 700, 875, 1050]),
            "Mulan Rouge": EachProperty("Mulan Rouge", (225, 17, 0), 18, 220, [90, 250, 700, 875, 1050]),
            "Han Xin Gardens": EachProperty("Han Xin Gardens", (225, 17, 0), 20, 240, [100, 300, 750, 925, 1100]),
            "Shatner Close": EachProperty("Shatner Close", (225, 225, 51), 22, 260, [110, 330, 800, 975, 1150]),
            "Picard Avenue": EachProperty("Picard Avenue", (225, 225, 51), 22, 260, [110, 330, 800, 975, 1150]),
            "Crusher Creek": EachProperty("Crusher Creek", (225, 225, 51), 22, 280, [120, 360, 850, 1025, 1200]),
            "Sirat Mews": EachProperty("Sirat Mews", (0, 153, 0), 26, 300, [130, 390, 900, 1100, 1275]),
            "Ghengis Crescent": EachProperty("Ghengis Crescent", (0, 153, 0), 26, 300, [130, 390, 900, 1100, 1275]),
            "Ibis Close": EachProperty("Ibis Close", (0, 153, 0), 28, 320, [28, 150, 450, 1000, 1200, 1400]),
            "James Webb Way": EachProperty("James Webb Way", (0, 0, 153), 35, 350, [175, 500, 1100, 1300, 1500]),
            "Turing Heights": EachProperty("Turing Heights", (0, 0, 153), 50, 400, [200, 600, 1400, 1700, 2000]),
            "Brighton Station": EachProperty("Brighton Station", "", 25, 200, [25, 50, 100, 200]),
            "Hove Station": EachProperty("Hove Station", "", 25, 200, [25, 50, 100, 200]),
            "Falmer Station": EachProperty("Falmer Station", "", 25, 200, [25, 50, 100, 200]),
            "Portslade Station": EachProperty("Portslade Station", "", 25, 200, [25, 50, 100, 200]),
            "Tesla Power Co": EachProperty("Tesla Power Co", "", 0, 150, []),
            "Edison Water": EachProperty("Edison Water", "", 0, 150, []),

        }

    def check(self, name):
        '''

        :param name:
        :return: returns name of each property
        '''
        return name in self.each_properties_class

    def get_property_class(self, name):
        '''

        :param name:
        :return: returns class of property
        '''
        return self.each_properties_class[name]

    def add(self, property):
        self.each_properties_class[property.get_name()] = property

    def remove(self, name):
        property_in_bank = self.each_properties_class.pop(name)
        return property_in_bank

    def get_properties(self):
        return self.each_properties_class
