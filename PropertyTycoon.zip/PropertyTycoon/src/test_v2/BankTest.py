from Bank import Bank
class BankTest:
    def __init__(self):
        self.bank = Bank(50000)
    "Check the balance if it is integer type"
    def get_balance1(self):
        balance = self.bank.get_balance()
        assert not type(balance) != int, " the balance is in incorrect type "
        print("everything is fine")
    "check the withdraw amount if removed to the bank"
    def withdraw1(self):
        before_balance = self.bank.get_balance()
        self.bank.withdraw(50)
        after_balance = self.bank.get_balance()
        assert not before_balance == after_balance, " incorrect No amount is withdrawn "
        print(" it have successfully withdraw ")

        assert not ((before_balance - 50) != after_balance), "it withdraw wrong amount"
        print("withdraw the correct amount")

    "check weather money is correctly deposited"
    def deposit1(self):
        before_balance = self.bank.get_balance()
        amount =  50
        self.bank.deposit(amount)
        after_balance = self.bank.get_balance()
        assert not before_balance == after_balance, "Incorrect No amount is deposit"
        print("deposit successfully")

    "check weather property is in mortgage"
    def check_mortagage(self):
        before_list = len(self.bank.get_mortgage_list())
        self.bank.add_mortgage("jhonson")
        after_list = len(self.bank.get_mortgage_list())

        assert not before_list == after_list, "No property added"
        print("property added successfully ")


bank = BankTest()
bank.check_mortagage()
