"""
Integration Testing of Properties and player properties.
"""
from property_information import PropertyInfo
from PlayerProperties import PlayerProperties


class PlayerPropertiesAndPropertyInfoTest:
    def __init__(self):
        self.property_info = PropertyInfo()
        self.player_properties = PlayerProperties()

    "Check weather the property has been deducted and added to the player properties"
    def check_property_test(self):
        property_name = "The Old Creek"
        retrieve_property = self.property_info.get_property_class(property_name)
        self.player_properties.add_property(retrieve_property)
        self.property_info.remove(property_name)

        found = self.player_properties.check_property(property_name)
        assert not found != True, "The Property has not been added to the player"
        print("The property has been added")

        "check if the property is removed from the properties"
        exist = self.property_info.check(property_name)
        assert not exist == True, "The property hasn't been removed"
        print("The property has been successfully removed")

