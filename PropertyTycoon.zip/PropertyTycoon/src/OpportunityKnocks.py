import Queue
import pygame


class Opportunity:

    def __init__(self):
        self.card = [
            [0, "Bank pays you\n"
                " divided of £50"],
            [1, "You have won a lip\n"
                "sync battle. Collect £100"],
            [2, "Advance to Turing Heights"],
            [3, "Advance to Han Xin Gardens. If you pass GO, collect £200"],
            [4, "Fined £15 for speeding"],
            [5, "Pay university fees of £150"],
            [6, "Take a trip to Hove station. If you pass GO collect £200"],
            [7, "Loan matures, collect £150"],
            [8, "You are assessed for repairs, £40/house, £115/hotel"],
            [9, "Advance to GO"],
            [10, "You are assessed for repairs, £25/house, £100/hotel"],
            [11, "Go back 3 spaces"],
            [12, "Advance to Skywalker Drive. If you pass GO collect £200"],
            [13, "Go to jail. Do not pass GO, do not collect £200"],
            [14, "Drunk in charge of a hoverboard. Fine £30"],
            [15, "Get out of jail free"]]
        self.money = {0: 50, 1: 50, 2: "Turing Heights", 3: "Han Xin Gardens", 4: 15, 5: 150, 6: "Hove Station",
                      7: 150,
                      8: [40], 9: "Go", 10: [25], 11: 3, 12: " Skywalker Drive", 13: "Go to Jail", 14: 30, 15: "jail free"}

        self.activation = {7, 22, 36}

    def print(self):
        return self.card

    def check(self):
        return self.card[0]

    def dequeue(self):
        item = self.card[0]
        self.card.pop(0)
        self.card.append(item)
        return item

    def check_board_activation(self, index):
        if index in self.activation:
            return True
        return False

    def card_operation(self, bank, player, card_index, free_parking):
        position = {2, 3, 6, 9, 12, 13}
        pay_bank = {0, 1, 7}
        pay_player = {5, 8, 10}
        parking = {4, 14}

        index = card_index[0]
        if index in pay_player:
            amount = self.money[index]
            player.withdraw(amount)
            bank.deposit(amount)
            print("succesffuly, player paid")
        elif index in pay_bank:
            amount = self.money[index]
            bank.withdraw(amount)
            player.deposit(amount)
            print("succesffuly, bank paid")

        elif index in parking:
            amount = self.money[index]
            player.withdraw(amount)
            free_parking.add_to_balance(amount)
            print("succesffuly, free parking paid")


        elif index == 15:
            player.add_card()

        elif index in position:
            jump_pos = self.money[index]
            return jump_pos




