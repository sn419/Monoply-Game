class node:
    def __init__(self, val):
        self.next = None
        self.val = val

class CurrentPlaying:
    def __init__(self):
        self.head = None
        self.total_players = 0
        self.current = self.head

    def add(self, player):
        if not self.head:
            self.head = node(player)
            self.head.next = self.head
        else:
            curr = self.head
            new_node = node(player)
            while curr.next != self.head:
                curr = curr.next
            curr.next = new_node
            new_node.next = self.head
        self.current = self.head
        self.total_players += 1

    def delete(self, player):
        '''

        :param player:
        :return:  removes the element from the head
        '''
        if self.head.val == player:
            curr = self.head
            while curr.next != self.head:
                curr = curr.next

            curr.next = self.head.next
            self.head = self.head.next
        else:
            prev = None
            curr = self.head
            while curr.next != self.head:
                prev = curr
                curr = curr.next
                if curr.val == player:
                    prev.next = curr.next
                    curr = curr.next

        self.total_players -= 1

    def check(self, player):
        curr = self.head
        while curr:
            if curr.val == player: return True
            curr = curr.next
        return False

    def length(self):
        return self.total_players

    def get_players(self):
        return self.head

    def print_players(self):
        curr = self.head
        while curr:

            print(curr.val)
            curr = curr.next
            if curr == self.head:
                break
    def turn(self):
        player = self.current.val
        return player

    def next_turn(self):
        self.current = self.current.next


    def AITurn(self):
        if "Ai" == self.current.val:
            return True








