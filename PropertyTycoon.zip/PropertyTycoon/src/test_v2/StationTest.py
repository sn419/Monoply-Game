from stations import personal_station


class StationTest:
    def __init__(self):
        self.station = personal_station()

    "check the increment rent"
    def increment_rent_test(self):
        current_rent = self.station.get_rent()
        self.station.increment_rent()
        after_increment_rent = self.station.get_rent()
        assert not after_increment_rent == current_rent, " The rent hasn't been increment"
        print("The rent has been updated successfully")

    " check weather the number of station is incremented "
    def check_station_test(self):
        " check weather a correct station is inserted "
        correct_station = "Falmer station"
        found = self.station.check_station(correct_station)
        assert not found == False, "the correct station is not found in station class"
        print("the correct station found successfully")

        " check weather a wrong station is inserted "
        wrong_station = "london station"
        found = self.station.check_station(wrong_station)
        assert not found == True, " The wrong station return True "
        print(" successfully identified the wrong station name ")

    " check the decrement rent "
    def decrement_rent_test(self):
        self.station.increment_rent()
        self.station.increment_rent()
        current_rent = self.station.get_rent()
        self.station.decrement_rent()
        after_decrement_rent = self.station.get_rent()
        assert not after_decrement_rent >= current_rent, "the rent unsuccessfully decremented"
        print("the rent has successfully decremented")


l = StationTest()
l.check_station_test()
