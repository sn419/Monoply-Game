class Queue:
    def __init__(self):
        self.deck = []

    def check(self):

        return self.deck[0]

    def dequeue(self):
        item = self.deck.pop(0)
        self.deck.append(item)

