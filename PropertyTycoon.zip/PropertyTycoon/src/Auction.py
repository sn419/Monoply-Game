class Auctions:
    def __init__(self, property):
        self.property = property
        self.current_bid_price = -1
        self.high_bid_player = None

    def get_highest_bidder(self):
        '''

        :return: returns the highest bidder
        '''
        return self.high_bid_player

    def set_highest_bidder(self, player):
        self.high_bid_player = player

    def get_property(self):
        '''

        :return: returns the property
        '''
        return self.property

    def get_bid_price(self):
        '''

        :return: returns the price of the bid
        '''
        return self.current_bid_price

    def set_bid_price(self, price):
        '''

        :param price: the price the player wants to player for the property
        :return: sets the bid price from what was given by the player
        '''
        self.current_bid_price = price





