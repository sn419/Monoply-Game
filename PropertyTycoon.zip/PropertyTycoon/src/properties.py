import Property
class properties:
    def __init__(self):
        self.total_properties = []
        self.total = 0

    def add_property(self, property):
        '''

        :param property: the property youve just bought
        :return: adds the current property to the total you already have
        '''
        self.total_properties.append(property)

    def see_property(self):
        '''

        :return: returns the name of the properties you have
        '''
        for element in self.total_properties:
            print(element.get_name())

    def get_property_cost(self,name):
        '''

        :param name:
        :return: returns the cost of the properties you own
        '''
        for property in self.total_properties:
            if property.get_name() == name:
                return property.get_cost()






