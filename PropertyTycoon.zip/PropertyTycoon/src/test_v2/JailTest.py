from Jail import JailCell

class JailTest:
    def __init__(self):
        self.jail = JailCell()
    "check weather a person went to jail"
    def addJailTest(self):
        self.jail.add_player('San')  # Adds a player to Jail'
        Inmates = self.jail.gettotalinmates()  # Variable to use function to get amount of jail players'
        assert not Inmates != 1, "Player incorrectly added"
        print('Player correctly added')

    "check weather a person is removed from jail"
    def removeplayer(self):
        self.jail.add_player('San')
        self.jail.remove_player('San')
        Inmates = self.jail.gettotalinmates()
        assert not Inmates != 0, "Player Incorrectly removed"
        print('Player correctly removed')

    "check weather correct player is added to jail"
    def check_player(self):
        name = "smith"
        self.jail.add_player(name)
        is_ine = self.jail.check_player(name)
        assert not is_ine != True, "The player has unsuccessfully founded"
        print("the Player has successfully founded")

    "check weather fine is set to the correct amount "
    def check_fine(self):
        fine = self.jail.get_fine()
        assert not fine != 50,"The correct fine is not showing"
        print("The correct rent is shown")

