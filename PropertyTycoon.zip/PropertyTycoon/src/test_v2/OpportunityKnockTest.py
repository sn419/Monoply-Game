from OpportunityKnocks import Opportunity


class OpportunityTest:
    def __init__(self):
        self.opportunity = Opportunity()

    "Check weather the remove card is at the end, once it picked"
    def pick_card_test(self):
        card = self.opportunity.dequeue()
        queue = self.opportunity.return_queue()
        assert card != queue[-1], "the card hasn't successfully added to the end"
        print("The card has successfully added to the end")

    "Check the hashmap to ensure it has the correct key and values"
    def card_reward_test(self):
        position = [2, 3, 6, 9, 12, 13]
        pay_bank = [0, 1, 7]
        pay_player = [5, 8, 10]
        parking = [4, 14]
        reward_hashmap = self.opportunity.get_money()


        "check player to check the key and value is integer"
        for i in range(len(pay_player)):
            value = reward_hashmap[pay_player[i]]
            assert type(value) != int,"for the player, it is incorrect data "
            print("for the player, it is correct data type ")

        for j in range(len(position)):
            location = reward_hashmap[position[j]]
            assert type(location) != str," for the position, it is incorrect data type"
            print("for the position, it is the correct data type")

        for x in range(len(pay_bank)):
            value = reward_hashmap[pay_bank[x]]
            assert type(value) != int,"for the bank, it is incorrect data "
            print("for the bank, it is correct data type ")




