from Utility import Utility


class UtilityTest:
    def __init__(self):
        self.utility = Utility()

    "Test weather it put the correct rent"
    def one_utility_rent(self, dice1, dice2):
        self.utility.add_utility()
        rent = self.utility.total_rent(dice1, dice2)

        total_rent = (dice1 + dice2) * 4
        assert rent != total_rent, "Proper rent isn't shown"
        print("the rent for one utility is correct")

    "test the total cost of two utilities"
    def two_utility_rent(self, dice1, dice2):
        " increment the utility  to check weather it gives the correct rent"
        self.utility.add_utility()
        self.utility.add_utility()
        rent = self.utility.total_rent(dice1, dice2)

        total_rent = (dice1 + dice2) * 10
        assert not total_rent != rent, "proper rent isn't shown"
        print("the rent for own utilities is correct")

    "test if utility is added"
    def check_adding(self):
        number_of_utilities = self.utility.get_utility()
        self.utility.add_utility()
        number_of_utilities_after = self.utility.get_utility()

        assert (number_of_utilities + 1) != number_of_utilities_after, 'number of utilities have incorrectly incremented'
        print("the utility count is correctly incremented")

    "test utility is removed correctly"
    def check_remove(self):
        self.utility.add_utility()

        utilities_amount = self.utility.get_utility()
        self.utility.remove_utility()
        utilities_after_amount = self.utility.get_utility()

        assert not utilities_amount == 0, "the number of utilities hasn't decremented"
        print("the utility count is correct decremented")


