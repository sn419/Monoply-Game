from PotLuck import potluck
class PotLuckTest:
    def __init__(self):
        self.potluck = potluck()

    "Check weather the remove card is at the end, once it picked"
    def pick_card_test(self):
        card = self.potluck.dequeue()
        queue = self.potluck.return_queue()
        assert card != queue[-1], "the card hasn't successfully added to the end"
        print("The card has successfully added to the end")

    def card_reward_test(self):
        Bank_pays = {0, 1, 3, 4, 8, 12, 14}
        player_pays = {5, 6, 9, 10, 11}
        position = {2, 7, 13}
        reward_hashmap = self.potluck.get_money()


        "check player to check the key and value is integer"
        for i in range(len(player_pays)):
            value = reward_hashmap[player_pays[i]]
            assert type(value) != int,"for the player, it is incorrect data "
            print("for the player, it is correct data type ")

        for j in range(len(position)):
            location = reward_hashmap[position[j]]
            assert type(location) != str," for the position, it is incorrect data type"
            print("for the position, it is the correct data type")

        for x in range(len(player_pays)):
            value = reward_hashmap[player_pays[x]]
            assert type(value) != int,"for the bank, it is incorrect data "
            print("for the bank, it is correct data type ")