" a circular LinkedList for the board to use"
from Property import EachProperty
from property_information import PropertyInfo
class node:
    def __init__(self, val):
        self.next = None
        self.val = val
        self.belong = None
        self.property = None

class LinkedList:
    def __init__(self):
        self.head = None

    def add(self, index):
        if not self.head:
            self.head = node(index)
            self.head.next = self.head
        else:
            curr = self.head
            new_node = node(index)
            while curr.next != self.head:
                curr = curr.next
            curr.next = new_node
            new_node.next = self.head

    def get_position(self, value):
        curr = self.head
        while curr:
            if curr.card_property == value:
                return curr
            curr = curr.next
        return -1

    def set_property(self, cell, player):
        cell.belong = player

    def check_property (self, cell):
        return cell.belong

    def return_head(self):
        return self.head


class board:
    def __init__(self):
        self.items = {1: "Go",
                      2: "The Old Creek",
                      3: "Pot Luck",
                      4: "Gangsters Paradise",
                      5: "Income Tax",
                      6: "Brighton Station",
                      7: "The Angels"
                         " Delight",
                      8: "Opportunity Knocks",
                      9: "Potter Avenue",
                      10: "Granger Drive",
                      11: "Jail/Just "
                          "visiting",
                      12: "Skywalker Drive",
                      13: "Tesla Power Co",
                      14: "Wookie Hole",
                      15: "Rey Lane",
                      16: "Hove Station",
                      17: "Bishop Drive",
                      18: "Pot Luck",
                      19: "Dunham Street",
                      20: "Broyles Lane",
                      21: "Free Parking",
                      22: "Yue Fei Square",
                      23: "Opportunity Knocks",
                      24: "Mulan Rouge",
                      25: "Han Xin Gardens",
                      26: "Falmer Station",
                      27: "Shatner Close",
                      28: "Picard Avenue",
                      29: "Edison Water",
                      30: "Crusher Creek",
                      31: "Go to Jail",
                      32: "Sirat Mews",
                      33: "Ghengis Crescent",
                      34: "Pot Luck",
                      35: "Ibis Close",
                      36: "Portslade Station",
                      37: "Opportunity Knocks",
                      38: "James Webb Way",
                      39: "Super Tax",
                      40: "Turing Heights",
                      }
        self.properties = {"The Old Creek",
                           "Gangsters Paradise",
                           "The Angels Delight",
                           "Potter Avenue",
                           "Granger Drive",
                           "Skywalker Drive",
                           "Wookie Hole",
                           "Rey Lane",
                           "Bishop Drive",
                           "Dunham Street",
                           "Broyles Lane",
                           "Yue Fei Square",
                           "Mulan Rouge",
                           "Han Xin Gardens",
                           "Shatner Close",
                           "Picard Avenue",
                           "Crusher Creek",
                           "Sirat Mews",
                           "Ghengis Crescent",
                           "Ibis Close",
                           "James Webb Way",
                           "Turing Heights",
                           "Brighton Station",
                           "Hove Station",
                           "Falmer Station",
                           "Portslade Station",
                           "Tesla Power Co",
                           "Edison Water"}

        self.board = LinkedList()
        self.place_index()
        self.head = self.board.return_head()
        self.cell_name_node = {}
        self.properties_class = PropertyInfo()




    def is_it_property(self,name):
        if name in self.properties:
            return True
        return False

    def place_index(self):
        for element in self.items:
            self.board.add(self.items[element])

    def increment(self, player_node, value):
        while value > 0:
            player_node = player_node.next
            value -= 1
        return player_node

    def add_property_class_to_cell(self):
        curr = self.head
        while curr:
            if curr.next == self.head:
                break
            else:
                if curr.val in self.properties:
                    l = self.properties_class.get_property_class(curr.val)
                    curr.property = l
            curr = curr.next
        if curr.val in self.properties and curr.property == None:
            curr.property = self.properties_class.get_property_class(curr.val)


    def get_board(self):
        return self.board

    def get_cell_items(self):
        return self.items

    def assign_cell_name(self):
        curr = self.head
        for i in range(40):
            self.cell_name_node[self.items[i + 1]] = curr
            curr = curr.next

    def get_cell_name_node(self, cell_name):
        return self.cell_name_node[cell_name]

    def get_head(self):
        return self.head

    def set_belong(self, node, name):
        node.belong = name

    def get_property(self, node):
        if node.property == None:
            return True
        else:
            return False


