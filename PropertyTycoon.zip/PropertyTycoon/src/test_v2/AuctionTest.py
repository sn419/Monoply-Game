from Auction import Auctions
from property_information import PropertyInfo

"Integration testing of the property and "


class auctionTest:
    def __init__(self):
        self.properties = PropertyInfo()
        self.property = self.properties.get_property_class("Falmer Station")
        self.auction = Auctions(self.property)

    "Check if the highest bidder is set "
    def highest_bidder_test(self):
        self.auction.set_highest_bidder("sanaullah")
        assert not self.auction.get_highest_bidder() is None, "The player hasn't been set"
        print("The player has been set correctly")

    "check if the property is to set"
    def property_set_test(self):
        assert not self.auction.get_property() is None, " The property hasn't been set "
        print(" The property has been set correctly ")


    "check wether the bid is set"
    def bid_set_test(self):
        initial_bid = self.auction.get_bid_price()
        price = 1200
        self.auction.set_bid_price(price)

        assert not self.auction.get_bid_price() != price, " the bid price hasn't been set"
        print("the bid price has been set correctly")

