from PlayingPlayers import CurrentPlaying
class Playingplayers_test:
    def __init__(self, players):
        self.player = players

    "check if the player exist"
    def player_exist(self, player):
        curr = self.player.get_players()
        first =curr
        while curr:
            assert not curr.val == player,"player hasn't been added"
            print("player has been added")

            curr = curr.next
            if curr == first:
                break

    "check if player is added"
    def add_item1(self, name):
        self.player.add(name)
        lengths = self.player.length()
        assert not (lengths == 0), "No player added"
        print("player added")

    "check if the player added correctly in the list"
    def check_player_exist(self, name):
        "Check if the correct player added"
        exist = self.player_exist(name)
        assert not (exist == False),"No player by the name added"
        print("the player have been added")
