class JailCell:
    def __init__(self):
        self.total_player = 0
        self.release_fine = 50
        self.players_in_jail = set()

    def remove_player(self, name):
        '''

        :param name: name of player
        :return: returns the name of the player being removed from jail
        '''
        self.players_in_jail.remove(name)
        self.total_player -=1
        print("successfully remove",self.players_in_jail)

    def add_player(self, name):
        '''

        :param name: name of player
        :return: returns the name of the player being added to jail
        '''
        self.players_in_jail.add(name)
        self.total_player += 1
        print("successfully added", self.players_in_jail)

    def show_people_in_jail(self):
        '''

        :return: shows the people in jail
        '''
        for element in self.players_in_jail:
            print(element)

    def get_fine(self):
        '''

        :return: returns the release fine
        '''
        return self.release_fine

    def check_player(self,name):
        '''

        :param name: name of person in jail
        :return: returns true if theres a player in jail, false otherwise
        '''
        if name in self.players_in_jail:
            return True
        return False

    # Test the class for any errors
    def gettotalinmates(self):
        return len(self.players_in_jail)