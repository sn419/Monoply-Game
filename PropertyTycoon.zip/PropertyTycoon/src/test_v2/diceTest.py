from Turn import Dice
class dice_test:
    def __init__(self, dice):
        self.dice = Dice()

    "check if the random generated number is between 1 and 6"
    def random(self):
        x = self.dice.random_number()
        assert x >= 1 and x <= 6, "Number must be in 1-6"
        print("Success")

    "check if the sum of two random number is between 1 and 12"
    def sum_two_dice(self):
        y = self.dice.get_dice_number()
        assert y >= 2 and y <= 12, "Number must be in 2-12"
        print("Success")


