from Bank import Bank
from PlayersPersonalInformation import PlayerInformation
from Board import board


class BankAndPlayerInformationTest:
    def __init__(self):
        self.board = board()
        self.bank = Bank(50000)
        self.playerinformation = PlayerInformation("sanaullah", "", (0, 0), True, self.board.head)

    " Check if money deducted and added to player"
    def player_add(self):
        amount = 100
        current_bank_balance = self.bank.get_balance()
        current_player_balance = self.playerinformation.get_balance()
        self.bank.withdraw(amount)
        self.playerinformation.deposit(amount)

        assert not current_player_balance + amount != self.playerinformation.get_balance(), "The money isn't added"
        print("the money has successfully added to the player")

        assert not current_bank_balance - amount != self.bank.get_balance(), "the money isn't deducted from bank"
        print("The money has sucessfully deducted from the bank")

    "check weather property is deducted and added to the player"
    def property_test(self):
        bank_properties = self.bank.get_own_bank_properties()
        property = bank_properties.get_property_class("Yue Fei Square")

        player_properties = self.playerinformation.Player_properties
        player_properties.add_property(property)

        assert not player_properties.get_length_properties() != 0, "the property is not added"
        print("The property has successfully added to the player")

    "deduct money from the player"
    def player_money_test(self):
        amount = 500
        bank_balance = self.bank.get_balance()
        player_balance = self.playerinformation.get_balance()
        self.playerinformation.withdraw(amount)
        self.bank.deposit(amount)

        assert not (self.playerinformation + amount != self.playerinformation.get_balance()),"The money hasn't been added"
        print("The amount has sucessfully added")
