class property_test:
    def __init__(self, property):
        self.property = property

    "check the name of the property"
    def get_name_1(self):
        name = self.property.get_name()
        assert type(name) != str, "The name is not in a string format"
        print(" it is in correct type format ")

    "checking the cost is in integer type"
    def get_cost_1(self):
        x = self.property.get_cost()
        assert type(x) != int or type(x) != float, " the cost is not in the correct type "
        print(" it is in correct type ")

    "checking the rent type "
    def get_rent1(self):
        rent = self.property.get_rent()
        assert type(rent) != int or type(rent) != float, " the cost is it in incorrect type "
        print(" It is in correct type ")

    "checking the property string type"
    def check_group(self):
        name = self.property.get_group()
        assert type(name) != str, "The name is not in a string format"
        print(" It is correct format")



"""
string ="kgfhgjkfhdgrhndkg"
data = data.convert(
packet =[0,2,data,0,]


if packet[1] == "2":
   call 

"""