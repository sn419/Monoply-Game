import pygame


class potlucktoken:
    def __init__(self, width, height, x, y):
        '''

        :param width: width of the image
        :param height: height of the image
        '''
        self.potluck_token = [pygame.image.load("images/PotLuck/Inherit200.png"),
                              pygame.image.load("images/PotLuck/Beauty50.png"),
                              pygame.image.load("images/PotLuck/BacktoOldCreek.png"),
                              pygame.image.load("images/PotLuck/StudentLoan20.png"),
                              pygame.image.load("images/PotLuck/BankError200.png"),
                              pygame.image.load("images/PotLuck/PayBill100.png"),
                              pygame.image.load("images/PotLuck/TaxiBill50.png"),
                              pygame.image.load("images/PotLuck/AdvancetoGoPotLuck.png"),
                              pygame.image.load("images/PotLuck/Bitcoin50.png"),
                              pygame.image.load("images/PotLuck/BitcoinPay.png"),
                              pygame.image.load("images/PotLuck/10orOppKnocks.png"),
                              pygame.image.load("images/PotLuck/InsuranceFee50.png"),
                              pygame.image.load("images/PotLuck/Savings100.png"),
                              pygame.image.load("images/PotLuck/GotoJailPotLuck.png"),
                              pygame.image.load("images/PotLuck/Shares25.png"),
                              pygame.image.load("images/PotLuck/Birthday10.png")]
        self.width = width
        self.height = height
        self.x = x
        self.y = y
        self.resize()
        self.front =  pygame.image.load("images/PotLuck/BackofCardPotLuck.png")

    def resize(self):
        for i in range(len(self.potluck_token)):
            self.potluck_token[i] = pygame.transform.scale(self.potluck_token[i], (self.width, self.height))

    def display_token(self, screen, token):
        screen.blit(token, (self.x, self.y))

    def dequeue(self):
        item = self.potluck_token[0]
        self.potluck_token.pop(0)
        self.potluck_token.append(item)
        return item

    def front_page(self):
        self.front = pygame.transform.scale(self.front, (self.width, self.height))
        return self.front
