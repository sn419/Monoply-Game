from property_information import PropertyInfo


class PropertyInformationTest:
    def __init__(self):
        self.properties = PropertyInfo()

    "check weather the property return is none and return the correct property"
    def get_property_class_test(self):
        name = "The Old Creek"
        single_property = self.properties.get_property_class(name)

        "check property is none"
        assert not single_property ==  None, "Property hasn't been returned"
        print("The property has been successfully returned")


    "check if the correct property is retrieved"
    def get_correct_property_test(self):
        name = "The Old Creek"
        single_property = self.properties.get_property_class(name)

        "check weather return the correct property"
        assert not name != single_property.get_name(), "return wrong property"
        print("it has return the correct property")

    "check weather property is removed"
    def property_remove_test(self):
        name = "Edison Water"
        property = self.properties.remove(name)
        assert not name != property.get_name(),"Wrong property has been removed"
        print("Correct property is removed")


        exist_in_hashmap = self.properties.check(name)
        assert not exist_in_hashmap,"The property hasn't been removed"
        print("The property has been removed")

    "checking if the property is inserted and exist"
    def property_add_test(self):
        first = self.properties.remove("Gangsters Paradise")
        second = self.properties.remove("Skywalker Drive")

        if  not self.properties.check(first):
            self.properties.add(first)
            exist_in_hashmap = self.properties.check(first)
            assert not exist_in_hashmap,"The property is not added"
            print("The property is added")

