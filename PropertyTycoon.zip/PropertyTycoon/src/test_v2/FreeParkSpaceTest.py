from FreeParkingSpace import FreeParking
class FreeParkingTest():
    def __init__(self):
        self.position = 20
        self.FreeParking = FreeParking(self.position)
    "check weather the fine is paid"
    def addtobalanceTest(self):
        self.FreeParking.add_to_balance(50) #Adds 50 to Free Parking
        BalanceTest = self.FreeParking.get_balance() # Gets the Balance
        assert not BalanceTest != 50,'Unsuccesful Test' #Tests to see if balance is equal to 50
        print('Successful test Free Parking')
    "check the position of the free parking space"
    def positionTest(self):
        positionTest = self.FreeParking.get_position()
        assert not positionTest != 20,'Unsuccesful Test'
        print('Successful Test Free Parking Position')


