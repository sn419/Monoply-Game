import pygame


class opportunityknock:
    def __init__(self, width, height, x, y):
        self.oppknock = [pygame.image.load("images/OppKnocks/BankPays50.png"),
                              pygame.image.load("images/OppKnocks/LipSync100.png"),
                              pygame.image.load("images/OppKnocks/AdvancetoTuringHeights.png"),
                              pygame.image.load("images/OppKnocks/AdvancetoHanXin.png"),
                              pygame.image.load("images/OppKnocks/Fine15.png"),
                              pygame.image.load("images/OppKnocks/PayUni.png"),
                              pygame.image.load("images/OppKnocks/HoveStation.png"),
                              pygame.image.load("images/OppKnocks/LoanCollect150.png"),
                              pygame.image.load("images/OppKnocks/Repairs40.png"),
                              pygame.image.load("images/OppKnocks/AdvancetoGoOppKnocks.png"),
                              pygame.image.load("images/OppKnocks/Repairs25.png"),
                              pygame.image.load("images/OppKnocks/Back3Spaces.png"),
                              pygame.image.load("images/OppKnocks/SkyWalkerDrive.png"),
                              pygame.image.load("images/OppKnocks/GoToJailOppKnocks.png"),
                              pygame.image.load("images/OppKnocks/Fine30.png"),
                              pygame.image.load("images/OppKnocks/GetoutofJailOppKnocks.png"),]
        self.width = width
        self.height = height
        self.x = x
        self.y = y
        self.resize()
        self.front =  pygame.image.load("images/OppKnocks/BackofCardOppKnocks.png")

    def resize(self):
        for i in range(len(self.oppknock)):
            self.oppknock[i] = pygame.transform.scale(self.oppknock[i], (self.width, self.height))

    def display_token(self, screen, token):
        screen.blit(token, (self.x, self.y))

    def dequeue(self):
        item = self.oppknock[0]
        self.oppknock.pop(0)
        self.oppknock.append(item)
        return item

    def front_page(self):
        self.front = pygame.transform.scale(self.front, (self.width, self.height))
        return self.front
